﻿netsh interface set interface name = "wi-fi" admin=enabled

