﻿wmic cpu get name,CurrentClockSpeed,MaxClockSpeed
wmic fan get CurrentFanSpeed