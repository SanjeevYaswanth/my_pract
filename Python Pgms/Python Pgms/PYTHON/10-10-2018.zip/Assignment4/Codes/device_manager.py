import subprocess
import sys
subprocess.Popen(['powershell.exe','Set-ExecutionPolicy RemoteSigned'], stdout=subprocess.PIPE)
subprocess.Popen(['powershell.exe','Set-ExecutionPolicy unrestricted'], stdout=subprocess.PIPE)
p = subprocess.Popen(['powershell.exe','F:\Training\Python_Assignments\Assignment4\mo\device_man.ps1'], stdout=subprocess.PIPE)
w = p.communicate()
o=str(w)
f=open("F:\Training\Python_Assignments\Assignment4\mof\device_out.txt", "wt")
f.write(o)

