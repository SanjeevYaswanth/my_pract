#program to read binary contents of a file
f = open("F:\Training\Python Assignments\Assignment1\sample.txt", "rb")
rd = f.read()
print(rd)