#program to write in to file using print statement
f = open("F:\Training\Python Assignments\Assignment1\pw",'w')
print('This is being imparted to the file using print statement', file=f) #file=f says that f needs to be written in the mentioned file
