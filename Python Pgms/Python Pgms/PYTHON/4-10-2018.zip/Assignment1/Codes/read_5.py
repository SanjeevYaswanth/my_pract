#iterating through whole file using for loop
f = open("F:\Training\Python Assignments\Assignment1\sample.txt", "rt")
for x in f:
    print(x)