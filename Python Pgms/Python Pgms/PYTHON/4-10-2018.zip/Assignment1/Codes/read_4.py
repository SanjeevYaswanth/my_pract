#reading first two lines of the file
f = open("F:\Training\Python Assignments\Assignment1\sample.txt", "rt")
print(f.readline())
print(f.readline())
