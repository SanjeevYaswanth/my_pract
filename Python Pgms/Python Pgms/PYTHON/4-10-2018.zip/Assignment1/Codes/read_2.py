#reading the first 5 characters present in the file
f = open("F:\Training\Python Assignments\Assignment1\sample.txt", "rt")
rd = f.read(5)
print(rd)