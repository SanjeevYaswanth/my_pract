#program to create afile using 'x' mode of open.
f = open("F:\Training\Python Assignments\Assignment1\sample_w.txt", "x")
f.write("This file has just been created and written") #this text will be written in the file after its creation.
print("file created")