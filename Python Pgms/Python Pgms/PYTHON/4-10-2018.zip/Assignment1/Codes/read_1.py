#program to read from text file
#reading full file
#then printing it
f = open("F:\Training\Python Assignments\Assignment1\sample.txt", "rt")
rd = f.read()
print(rd)