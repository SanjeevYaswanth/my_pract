#program to write contents into the mentioned file using 'w' mode of open()
f = open("F:\Training\Python Assignments\Assignment1\sample_w.txt", "w")
f.write("this file has been created using python write and w mode \n \n next line brought using endline i.e. '\n'")

