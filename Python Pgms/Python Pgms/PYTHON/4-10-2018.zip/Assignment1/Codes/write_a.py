#program to append contents in a file using 'a' mode of open()
f = open("F:\Training\Python Assignments\Assignment1\sample_w.txt", "a")
f.write("this line is being appended to the file which was previously created.")