'''program to find date, year and country names in file'''
from collections import OrderedDict '''importing required modules'''
import re
f = open("F:/Training/Python_Assignments/Assignment3/text.txt", "rt")
rd = f.read() '''reading the file to be extracted from'''
country = ["Japan", "China", "United States", "Germany", "Poland", "France", "Britain"]
'''print("Year ")'''
year = re.findall(r"[0-9]{4}", rd) '''finding years'''
'''print(year)
print("Date ")'''
dates = re.findall(r"[0-9]{1,2} [A-z]{4,10} [0-2]{1}[0-9]{3}", rd) '''finding dates'''
'''print(dates)'''
rd1 = ' '.join(OrderedDict((d,d) for d in rd.split()).keys()) '''splitting the words to get city names'''
with open("F:/Training/Python_Assignments/Assignment3/output.txt", 'wt') as w: '''writing the output in other file'''
    for item in year:
        w.write("%s\n" % item)
    for i in dates:
        w.write("%s\n" % i)
    for j in country:
        m = re.findall(j, rd1)
        for cou in m:
            w.write(cou)