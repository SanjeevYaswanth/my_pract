'''Program to get mail ids phone nos and city names from web page'''
'''importing required modules'''
import re
import urllib.request
'''reading the required entries using respective regexs''' 
with urllib.request.urlopen("http://www.python.org") as url:
    rd = url.read().decode()
e_mail = re.findall(r"[a-z]{4,10}@redbus.com", rd)
ph = re.findall(r"Ph:[0-9]{3}-[0-9]{3,9}", rd)
city = re.findall(r"[A-Z]{3,10}", rd)
'''writing them in file'''
with open("F:\Training\Python_Assignments\Assignment3\output_net.txt", "wt") as w:
    for mail in e_mail:
        print(mail)
        w.write(mail)
    for phone in ph:
        w.write(phone)
    for c in city:
        w.write(c)