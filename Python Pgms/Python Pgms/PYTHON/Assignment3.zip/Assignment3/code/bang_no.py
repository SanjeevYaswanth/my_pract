#Validate any land-phone no belongs to bangalore.
#importing regular expression module
import re
#creating a list
print("Enter the number to be checked:")
li=[input()]
#taking for loop
for val in li:
    #re.match function two arguments pattern and string nad len is fixed
    if re.match(r'[0]{1}[8]{1}[0]{1}[0-9]{8}', val) and len(val) == 11:
        print('Yes,the landline number is of bangalore.')
    elif re.match(r'[0]{1}[8]{1}[0]{1}[-]{1}[0-9]{8}',val) and len(val) == 12:
        print ('Yes,the landline number is of bangalore.')
    else:
        print ('No,the number is invalid')