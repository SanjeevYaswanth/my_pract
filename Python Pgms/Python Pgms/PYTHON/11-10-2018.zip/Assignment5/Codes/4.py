import subprocess
import sys
subprocess.Popen(['powershell.exe','Set-ExecutionPolicy RemoteSigned'], stdout=subprocess.PIPE)
subprocess.Popen(['powershell.exe','Set-ExecutionPolicy unrestricted'], stdout=subprocess.PIPE)
p = subprocess.Popen(['powershell.exe','F:\Training\Python_Assignments\Assignment5\mo\server_ws.ps1'], stdout=subprocess.PIPE)
w = p.communicate()
o=str(w)
f=open("F:\Training\Python_Assignments\Assignment5\mfo\server_ws.txt", "wt")
f.write(o)

