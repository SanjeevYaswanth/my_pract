﻿Get-WmiObject Win32_OperatingSystem | fl *free*
