﻿$osInfo = Get-WmiObject -Class Win32_OperatingSystem
if($osInfo.ProductType)
{
echo"Workstation"
}
 #value is 1: workstation OS| 2:domain controller| 3: server that is not a domain controller.
