﻿New-ItemProperty -Path "HKCU:\EUDC\NetwrixKey" -Name "NetwrixParam" -Value ”NetwrixValue”  -PropertyType "String"
